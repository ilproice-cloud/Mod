package com.realmforge.client;

import com.realmforge.network.SyncPayload;
import com.realmforge.player.StatType;

import java.util.ArrayList;
import java.util.List;

/** Client-side copy of the player's RPG data, filled by SyncPayload. */
public final class ClientRPGData {
    private ClientRPGData() {}

    public static int level = 1;
    public static int xp = 0;
    public static int xpNeeded = 100;
    public static int points = 0;
    public static int energy = 100;
    public static int maxEnergy = 100;
    public static String race = "";
    public static final int[] stats = new int[StatType.values().length];
    public static final List<String> traits = new ArrayList<>();

    public static void apply(SyncPayload p) {
        level = p.level();
        xp = p.xp();
        xpNeeded = p.xpNeeded();
        points = p.points();
        energy = p.energy();
        maxEnergy = p.maxEnergy();
        race = p.race();
        for (int i = 0; i < stats.length; i++) {
            stats[i] = i < p.stats().size() ? p.stats().get(i) : 0;
        }
        traits.clear();
        traits.addAll(p.traits());
    }
}
