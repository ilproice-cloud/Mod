package com.realmforge.progression;

import net.minecraft.util.Formatting;

public final class RankManager {
    private RankManager() {}

    public enum Rank {
        NOVICE("Novice", 1, Formatting.GRAY),
        APPRENTICE("Apprentice", 10, Formatting.GREEN),
        ADEPT("Adept", 20, Formatting.AQUA),
        VETERAN("Veteran", 30, Formatting.BLUE),
        EXPERT("Expert", 40, Formatting.DARK_PURPLE),
        MASTER("Master", 55, Formatting.GOLD),
        GRANDMASTER("Grandmaster", 70, Formatting.RED),
        LEGEND("Legend", 85, Formatting.LIGHT_PURPLE),
        ASCENDED("Ascended", 100, Formatting.YELLOW);

        public final String displayName;
        public final int minLevel;
        public final Formatting color;

        Rank(String displayName, int minLevel, Formatting color) {
            this.displayName = displayName;
            this.minLevel = minLevel;
            this.color = color;
        }
    }

    public static Rank forLevel(int level) {
        Rank result = Rank.NOVICE;
        for (Rank r : Rank.values()) {
            if (level >= r.minLevel) result = r;
        }
        return result;
    }
}
