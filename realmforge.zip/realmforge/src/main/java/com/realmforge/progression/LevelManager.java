package com.realmforge.progression;

import com.realmforge.RealmforgeConfig;
import com.realmforge.network.RPGNetworkHandler;
import com.realmforge.player.BonusType;
import com.realmforge.player.PlayerStats;
import com.realmforge.player.RPGPlayerData;
import com.realmforge.player.StatType;
import com.realmforge.rarity.RarityManager;
import com.realmforge.registry.Perk;
import com.realmforge.registry.PerkRegistry;
import com.realmforge.registry.Trait;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashSet;

public final class LevelManager {
    private LevelManager() {}

    public static int xpNeeded(int level) {
        return (int) (80 + 40 * level + 2.5 * level * level);
    }

    public static void addXp(ServerPlayerEntity player, int amount) {
        RPGPlayerData d = RPGPlayerData.get(player);
        if (d.level >= RealmforgeConfig.MAX_LEVEL || amount <= 0) return;

        double mult = 1.0 + PlayerStats.bonus(d, BonusType.XP_GAIN) / 100.0;
        int gained = (int) Math.max(1, Math.round(amount * mult));
        d.xp += gained;
        player.sendMessage(Text.literal("+" + gained + " XP").formatted(Formatting.GREEN), true);

        boolean leveled = false;
        while (d.level < RealmforgeConfig.MAX_LEVEL && d.xp >= xpNeeded(d.level)) {
            d.xp -= xpNeeded(d.level);
            d.level++;
            d.points += RealmforgeConfig.POINTS_PER_LEVEL;
            leveled = true;
            onLevelUp(player, d);
        }
        if (d.level >= RealmforgeConfig.MAX_LEVEL) d.xp = 0;

        if (leveled) {
            PlayerStats.applyAttributes(player);
            player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP,
                    SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
        d.save(player);
        RPGNetworkHandler.sync(player);
    }

    private static void onLevelUp(ServerPlayerEntity player, RPGPlayerData d) {
        RankManager.Rank rank = RankManager.forLevel(d.level);
        player.sendMessage(Text.literal("Level Up! ").formatted(Formatting.GOLD, Formatting.BOLD)
                .append(Text.literal("You are now level " + d.level + " (")
                        .formatted(Formatting.WHITE))
                .append(Text.literal(rank.displayName).formatted(rank.color))
                .append(Text.literal(") +" + RealmforgeConfig.POINTS_PER_LEVEL + " stat points")
                        .formatted(Formatting.WHITE)));

        for (Perk perk : PerkRegistry.unlockedAt(d.level)) {
            player.sendMessage(Text.literal("Perk unlocked: ").formatted(Formatting.GRAY)
                    .append(Text.literal(perk.name()).formatted(perk.rarity().color))
                    .append(Text.literal(" (" + perk.describeBonuses() + ")").formatted(Formatting.GRAY)));
        }

        if (d.level % RealmforgeConfig.TRAIT_INTERVAL == 0 && d.traits.size() < RealmforgeConfig.MAX_TRAITS) {
            grantTrait(player, d);
        }
    }

    public static void grantTrait(ServerPlayerEntity player, RPGPlayerData d) {
        Trait trait = RarityManager.rollTrait(new HashSet<>(d.traits));
        if (trait == null) return;
        d.traits.add(trait.id());
        player.sendMessage(Text.literal("New Trait: ").formatted(Formatting.GRAY)
                .append(Text.literal("[" + trait.rarity().displayName + "] " + trait.name())
                        .formatted(trait.rarity().color))
                .append(Text.literal(" (" + trait.describeBonuses() + ")").formatted(Formatting.GRAY)));
    }

    /** Server-validated stat spend. Returns false if the player lacks points. */
    public static boolean spend(ServerPlayerEntity player, StatType stat, int amount) {
        RPGPlayerData d = RPGPlayerData.get(player);
        if (amount <= 0 || d.points < amount) return false;

        d.points -= amount;
        d.stats[stat.ordinal()] += amount;
        PlayerStats.applyAttributes(player);

        if (stat == StatType.VITALITY) {
            player.heal((float) (RealmforgeConfig.HP_PER_VITALITY * amount));
        }
        if (stat == StatType.ENERGY) {
            d.energy = Math.min(PlayerStats.maxEnergy(d), d.energy + RealmforgeConfig.ENERGY_PER_POINT * amount);
        }
        d.save(player);
        RPGNetworkHandler.sync(player);
        return true;
    }

    /** Clears and re-rolls traits (admin/testing). */
    public static void rerollTraits(ServerPlayerEntity player) {
        RPGPlayerData d = RPGPlayerData.get(player);
        int count = Math.min(RealmforgeConfig.MAX_TRAITS, d.level / RealmforgeConfig.TRAIT_INTERVAL);
        d.traits.clear();
        for (int i = 0; i < count; i++) grantTrait(player, d);
        PlayerStats.applyAttributes(player);
        d.save(player);
        RPGNetworkHandler.sync(player);
    }
}
