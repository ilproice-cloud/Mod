package com.realmforge.network;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Server -> Client: full snapshot of the player's RPG data. */
public record SyncPayload(int level, int xp, int xpNeeded, int points, int energy, int maxEnergy,
                          List<Integer> stats, List<String> traits, String race) implements CustomPayload {

    public static final Id<SyncPayload> ID = new Id<>(Identifier.of("realmforge", "sync"));

    public static final PacketCodec<RegistryByteBuf, SyncPayload> CODEC = new PacketCodec<RegistryByteBuf, SyncPayload>() {
        @Override
        public SyncPayload decode(RegistryByteBuf buf) {
            int level = buf.readVarInt();
            int xp = buf.readVarInt();
            int xpNeeded = buf.readVarInt();
            int points = buf.readVarInt();
            int energy = buf.readVarInt();
            int maxEnergy = buf.readVarInt();
            int statCount = buf.readVarInt();
            List<Integer> stats = new ArrayList<>();
            for (int i = 0; i < statCount; i++) stats.add(buf.readVarInt());
            int traitCount = buf.readVarInt();
            List<String> traits = new ArrayList<>();
            for (int i = 0; i < traitCount; i++) traits.add(buf.readString());
            String race = buf.readString();
            return new SyncPayload(level, xp, xpNeeded, points, energy, maxEnergy, stats, traits, race);
        }

        @Override
        public void encode(RegistryByteBuf buf, SyncPayload p) {
            buf.writeVarInt(p.level());
            buf.writeVarInt(p.xp());
            buf.writeVarInt(p.xpNeeded());
            buf.writeVarInt(p.points());
            buf.writeVarInt(p.energy());
            buf.writeVarInt(p.maxEnergy());
            buf.writeVarInt(p.stats().size());
            for (int s : p.stats()) buf.writeVarInt(s);
            buf.writeVarInt(p.traits().size());
            for (String t : p.traits()) buf.writeString(t);
            buf.writeString(p.race());
        }
    };

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
