package com.realmforge.player;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.realmforge.RealmforgeConfig;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Per-player RPG data. Persisted with the Fabric Data Attachment API and kept on death. */
public class RPGPlayerData {
    // CODEC must be declared before TYPE (TYPE's builder uses it immediately).
    public static final Codec<RPGPlayerData> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.INT.optionalFieldOf("level", 1).forGetter(d -> d.level),
            Codec.INT.optionalFieldOf("xp", 0).forGetter(d -> d.xp),
            Codec.INT.optionalFieldOf("points", 0).forGetter(d -> d.points),
            Codec.INT.optionalFieldOf("energy", RealmforgeConfig.BASE_ENERGY).forGetter(d -> d.energy),
            Codec.INT.listOf().optionalFieldOf("stats", List.of()).forGetter(RPGPlayerData::statList),
            Codec.STRING.listOf().optionalFieldOf("traits", List.of()).forGetter(d -> d.traits),
            Codec.STRING.optionalFieldOf("race", "").forGetter(d -> d.race)
    ).apply(inst, RPGPlayerData::new));

    public static final AttachmentType<RPGPlayerData> TYPE = AttachmentRegistry.create(
            Identifier.of("realmforge", "rpg_data"),
            builder -> builder
                    .persistent(CODEC)
                    .copyOnDeath()
                    .initializer(RPGPlayerData::new));

    public int level;
    public int xp;
    public int points;
    public int energy;
    public final int[] stats = new int[StatType.values().length];
    public final List<String> traits = new ArrayList<>();
    public String race;

    /** New player defaults. */
    public RPGPlayerData() {
        this(1, 0, RealmforgeConfig.START_POINTS, RealmforgeConfig.BASE_ENERGY, List.of(), List.of(), "");
    }

    public RPGPlayerData(int level, int xp, int points, int energy,
                         List<Integer> stats, List<String> traits, String race) {
        this.level = Math.max(1, level);
        this.xp = Math.max(0, xp);
        this.points = Math.max(0, points);
        this.energy = Math.max(0, energy);
        for (int i = 0; i < this.stats.length && i < stats.size(); i++) {
            this.stats[i] = Math.max(0, stats.get(i));
        }
        this.traits.addAll(traits);
        this.race = race;
    }

    public static void init() {
        // Touching the class registers the attachment during mod init.
    }

    public static RPGPlayerData get(ServerPlayerEntity player) {
        return player.getAttachedOrCreate(TYPE);
    }

    public void save(ServerPlayerEntity player) {
        player.setAttached(TYPE, this);
    }

    public int getStat(StatType type) {
        return stats[type.ordinal()];
    }

    public List<Integer> statList() {
        List<Integer> list = new ArrayList<>();
        for (int s : stats) list.add(s);
        return list;
    }
}
