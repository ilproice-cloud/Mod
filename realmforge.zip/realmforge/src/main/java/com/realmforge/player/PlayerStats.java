package com.realmforge.player;

import com.realmforge.RealmforgeConfig;
import com.realmforge.registry.PerkRegistry;
import com.realmforge.registry.Perk;
import com.realmforge.registry.Race;
import com.realmforge.registry.RaceRegistry;
import com.realmforge.registry.Trait;
import com.realmforge.registry.TraitRegistry;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

/** All stat math lives here so the screen, commands and mixin agree. */
public final class PlayerStats {
    private PlayerStats() {}

    private static final Identifier HEALTH_ID = Identifier.of("realmforge", "max_health");
    private static final Identifier SPEED_ID = Identifier.of("realmforge", "move_speed");
    private static final Identifier ARMOR_ID = Identifier.of("realmforge", "armor");
    private static final Identifier LUCK_ID = Identifier.of("realmforge", "luck");

    /** Sum of one bonus type across race, traits and unlocked perks. */
    public static double bonus(RPGPlayerData d, BonusType type) {
        double sum = 0;
        Race race = RaceRegistry.get(d.race);
        if (race != null) sum += sumOf(race, type);
        for (String id : d.traits) {
            Trait t = TraitRegistry.get(id);
            if (t != null) sum += sumOf(t, type);
        }
        for (Perk p : PerkRegistry.unlocked(d.level)) sum += sumOf(p, type);
        return sum;
    }

    private static double sumOf(BonusSource source, BonusType type) {
        double sum = 0;
        for (Bonus b : source.bonuses()) {
            if (b.type() == type) sum += b.value();
        }
        return sum;
    }

    public static int maxEnergy(RPGPlayerData d) {
        return RealmforgeConfig.BASE_ENERGY
                + RealmforgeConfig.ENERGY_PER_POINT * d.getStat(StatType.ENERGY)
                + (int) Math.round(bonus(d, BonusType.MAX_ENERGY));
    }

    /** Damage multiplier for an attacker. Magic damage uses Intelligence, everything else Strength. */
    public static double damageMultiplier(RPGPlayerData d, boolean magic) {
        double pct = magic
                ? RealmforgeConfig.MAGIC_DMG_PCT_PER_INTELLIGENCE * d.getStat(StatType.INTELLIGENCE)
                : RealmforgeConfig.PHYSICAL_DMG_PCT_PER_STRENGTH * d.getStat(StatType.STRENGTH);
        pct += bonus(d, BonusType.DAMAGE);
        return Math.max(0.0, 1.0 + pct / 100.0);
    }

    /** 0..0.75 fraction of damage removed. */
    public static double damageReduction(RPGPlayerData d) {
        double pct = RealmforgeConfig.REDUCTION_PCT_PER_DEFENSE * d.getStat(StatType.DEFENSE)
                + bonus(d, BonusType.DAMAGE_REDUCTION);
        return Math.max(0.0, Math.min(RealmforgeConfig.DEFENSE_CAP_PCT, pct)) / 100.0;
    }

    /** Crit chance in percent. */
    public static double critChance(RPGPlayerData d) {
        return Math.max(0.0, RealmforgeConfig.CRIT_PCT_PER_LUCK * d.getStat(StatType.LUCK)
                + bonus(d, BonusType.CRIT_CHANCE));
    }

    /** Dodge chance in percent. */
    public static double dodgeChance(RPGPlayerData d) {
        double pct = RealmforgeConfig.DODGE_PCT_PER_AGILITY * d.getStat(StatType.AGILITY)
                + bonus(d, BonusType.DODGE);
        return Math.max(0.0, Math.min(RealmforgeConfig.DODGE_CAP_PCT, pct));
    }

    /** Re-applies every attribute-based bonus to the player. Safe to call repeatedly. */
    public static void applyAttributes(ServerPlayerEntity player) {
        RPGPlayerData d = RPGPlayerData.get(player);

        double hp = RealmforgeConfig.HP_PER_VITALITY * d.getStat(StatType.VITALITY)
                + bonus(d, BonusType.MAX_HEALTH);
        double speedPct = RealmforgeConfig.SPEED_PCT_PER_AGILITY * d.getStat(StatType.AGILITY)
                + bonus(d, BonusType.MOVE_SPEED);
        double armor = bonus(d, BonusType.ARMOR);
        double luck = RealmforgeConfig.LUCK_ATTRIBUTE_PER_LUCK * d.getStat(StatType.LUCK);

        setModifier(player, EntityAttributes.GENERIC_MAX_HEALTH, HEALTH_ID, hp,
                EntityAttributeModifier.Operation.ADD_VALUE);
        setModifier(player, EntityAttributes.GENERIC_MOVEMENT_SPEED, SPEED_ID, speedPct / 100.0,
                EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        setModifier(player, EntityAttributes.GENERIC_ARMOR, ARMOR_ID, armor,
                EntityAttributeModifier.Operation.ADD_VALUE);
        setModifier(player, EntityAttributes.GENERIC_LUCK, LUCK_ID, luck,
                EntityAttributeModifier.Operation.ADD_VALUE);

        if (player.getHealth() > player.getMaxHealth()) {
            player.setHealth(player.getMaxHealth());
        }
        d.energy = Math.min(d.energy, maxEnergy(d));
    }

    private static void setModifier(ServerPlayerEntity player, RegistryEntry<EntityAttribute> attribute,
                                    Identifier id, double value, EntityAttributeModifier.Operation op) {
        EntityAttributeInstance instance = player.getAttributeInstance(attribute);
        if (instance == null) return;
        instance.removeModifier(id);
        if (value != 0) {
            // Persistent so health is not clamped when the player logs back in.
            instance.addPersistentModifier(new EntityAttributeModifier(id, value, op));
        }
    }
}
