package com.realmforge.player;

import net.minecraft.util.Formatting;

import java.util.Locale;

public enum StatType {
    VITALITY("Vitality", "+5 Max HP", Formatting.RED),
    STRENGTH("Strength", "+2% physical damage", Formatting.GOLD),
    AGILITY("Agility", "+0.5% speed, +0.05% dodge", Formatting.GREEN),
    INTELLIGENCE("Intelligence", "+2% magic damage", Formatting.AQUA),
    ENERGY("Energy", "+2 Max Energy", Formatting.YELLOW),
    DEFENSE("Defense", "+0.2% damage reduction", Formatting.BLUE),
    LUCK("Luck", "+0.25% crit, better loot", Formatting.LIGHT_PURPLE);

    public final String displayName;
    public final String description;
    public final Formatting color;

    StatType(String displayName, String description, Formatting color) {
        this.displayName = displayName;
        this.description = description;
        this.color = color;
    }

    /** Matches a full name or a unique prefix ("vit", "str", ...). Returns null if no unique match. */
    public static StatType fromName(String input) {
        String s = input.toLowerCase(Locale.ROOT);
        StatType match = null;
        for (StatType t : values()) {
            String n = t.name().toLowerCase(Locale.ROOT);
            if (n.equals(s)) return t;
            if (n.startsWith(s)) {
                if (match != null) return null;
                match = t;
            }
        }
        return match;
    }
}
