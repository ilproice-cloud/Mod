package com.realmforge.player;

import java.util.List;
import java.util.stream.Collectors;

/** Anything that grants bonuses: races, traits, perks. */
public interface BonusSource {
    List<Bonus> bonuses();

    default String describeBonuses() {
        return bonuses().stream().map(Bonus::describe).collect(Collectors.joining(", "));
    }
}
