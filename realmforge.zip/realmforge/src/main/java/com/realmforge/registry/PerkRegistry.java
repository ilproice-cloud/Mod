package com.realmforge.registry;

import com.realmforge.player.Bonus;
import com.realmforge.player.BonusType;
import com.realmforge.rarity.Rarity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PerkRegistry {
    private PerkRegistry() {}

    private static final Map<String, Perk> PERKS = new LinkedHashMap<>();

    static {
        reg("grit", "Adventurer's Grit", Rarity.COMMON, 5, b(BonusType.MAX_HEALTH, 2));
        reg("seasoned", "Seasoned Fighter", Rarity.UNCOMMON, 10, b(BonusType.DAMAGE, 3));
        reg("battle_hardened", "Battle Hardened", Rarity.RARE, 20, b(BonusType.ARMOR, 1), b(BonusType.DAMAGE_REDUCTION, 2));
        reg("second_breath", "Second Breath", Rarity.RARE, 30, b(BonusType.MAX_ENERGY, 20));
        reg("veterans_resolve", "Veteran's Resolve", Rarity.EPIC, 45, b(BonusType.MAX_HEALTH, 6), b(BonusType.DAMAGE_REDUCTION, 3));
        reg("master_duelist", "Master Duelist", Rarity.EPIC, 60, b(BonusType.DAMAGE, 8), b(BonusType.CRIT_CHANCE, 3));
        reg("legend_reborn", "Legend Reborn", Rarity.LEGENDARY, 80, b(BonusType.MAX_HEALTH, 10), b(BonusType.DAMAGE, 10));
        reg("eternal_ascendant", "Eternal Ascendant", Rarity.MYTHIC, 100,
                b(BonusType.MAX_HEALTH, 10), b(BonusType.DAMAGE, 10), b(BonusType.XP_GAIN, 10));
    }

    private static Bonus b(BonusType type, double value) {
        return new Bonus(type, value);
    }

    private static void reg(String id, String name, Rarity rarity, int level, Bonus... bonuses) {
        PERKS.put(id, new Perk(id, name, rarity, level, List.of(bonuses)));
    }

    public static void init() {}

    public static Collection<Perk> all() {
        return PERKS.values();
    }

    public static List<Perk> unlocked(int level) {
        List<Perk> list = new ArrayList<>();
        for (Perk p : PERKS.values()) {
            if (p.level() <= level) list.add(p);
        }
        return list;
    }

    public static List<Perk> unlockedAt(int level) {
        List<Perk> list = new ArrayList<>();
        for (Perk p : PERKS.values()) {
            if (p.level() == level) list.add(p);
        }
        return list;
    }
}
