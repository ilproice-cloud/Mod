package com.realmforge.registry;

import com.realmforge.player.Bonus;
import com.realmforge.player.BonusSource;
import net.minecraft.util.Formatting;

import java.util.List;

public record Race(String id, String name, Formatting color, String lore, List<Bonus> bonuses) implements BonusSource {
}
