package com.realmforge.registry;

import com.realmforge.player.Bonus;
import com.realmforge.player.BonusSource;
import com.realmforge.rarity.Rarity;

import java.util.List;

/** A passive reward that unlocks automatically at a level. */
public record Perk(String id, String name, Rarity rarity, int level, List<Bonus> bonuses) implements BonusSource {
}
