package com.realmforge.registry;

import com.realmforge.player.Bonus;
import com.realmforge.player.BonusType;
import net.minecraft.util.Formatting;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class RaceRegistry {
    private RaceRegistry() {}

    private static final Map<String, Race> RACES = new LinkedHashMap<>();

    static {
        reg("human", "Human", Formatting.WHITE, "Adaptable and quick to learn.",
                new Bonus(BonusType.XP_GAIN, 8));
        reg("elf", "Elf", Formatting.GREEN, "Graceful and swift, but frail.",
                new Bonus(BonusType.MOVE_SPEED, 5), new Bonus(BonusType.DODGE, 2), new Bonus(BonusType.MAX_HEALTH, -2));
        reg("dwarf", "Dwarf", Formatting.GOLD, "Stout and hard to hurt, but slow.",
                new Bonus(BonusType.ARMOR, 2), new Bonus(BonusType.MAX_HEALTH, 4), new Bonus(BonusType.MOVE_SPEED, -3));
        reg("orc", "Orc", Formatting.DARK_RED, "Brutal strength at the cost of stamina.",
                new Bonus(BonusType.DAMAGE, 6), new Bonus(BonusType.MAX_ENERGY, -10));
    }

    private static void reg(String id, String name, Formatting color, String lore, Bonus... bonuses) {
        RACES.put(id, new Race(id, name, color, lore, List.of(bonuses)));
    }

    public static void init() {}

    public static Race get(String id) {
        return id == null || id.isEmpty() ? null : RACES.get(id);
    }

    public static Collection<Race> all() {
        return RACES.values();
    }
}
