package com.realmforge.registry;

import com.realmforge.player.Bonus;
import com.realmforge.player.BonusSource;
import com.realmforge.rarity.Rarity;

import java.util.List;

public record Trait(String id, String name, Rarity rarity, List<Bonus> bonuses) implements BonusSource {
}
