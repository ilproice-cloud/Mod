package com.realmforge;

import com.realmforge.command.RPGCommands;
import com.realmforge.event.RPGEvents;
import com.realmforge.network.RPGNetworkHandler;
import com.realmforge.player.RPGPlayerData;
import com.realmforge.registry.PerkRegistry;
import com.realmforge.registry.RaceRegistry;
import com.realmforge.registry.TraitRegistry;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RealmforgeMod implements ModInitializer {
    public static final String MOD_ID = "realmforge";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        RPGPlayerData.init();
        TraitRegistry.init();
        PerkRegistry.init();
        RaceRegistry.init();

        RPGNetworkHandler.registerServer();
        RPGEvents.register();
        RPGCommands.register();

        LOGGER.info("Realmforge loaded. Ascend. Forge. Conquer.");
    }
}
