package com.realmforge.mixin;

import com.realmforge.RealmforgeConfig;
import com.realmforge.player.BonusType;
import com.realmforge.player.PlayerStats;
import com.realmforge.player.RPGPlayerData;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Fabric has no "modify damage" event, so Strength, Intelligence, Defense, crit,
 * dodge and lifesteal are applied here.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void realmforge$dodge(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.getWorld().isClient || !(self instanceof ServerPlayerEntity player)) return;
        if (source.getAttacker() == null || amount <= 0) return;

        double chance = PlayerStats.dodgeChance(RPGPlayerData.get(player));
        if (chance > 0 && self.getRandom().nextDouble() * 100.0 < chance) {
            player.sendMessage(Text.literal("Dodged!").formatted(Formatting.GRAY), true);
            cir.setReturnValue(false);
        }
    }

    @ModifyVariable(method = "damage", at = @At("HEAD"), argsOnly = true)
    private float realmforge$scaleDamage(float amount, DamageSource source) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.getWorld().isClient || amount <= 0) return amount;

        float result = amount;

        // Attacker bonuses
        if (source.getAttacker() instanceof ServerPlayerEntity attacker && attacker != self) {
            RPGPlayerData data = RPGPlayerData.get(attacker);
            boolean magic = source.isOf(DamageTypes.MAGIC) || source.isOf(DamageTypes.INDIRECT_MAGIC);

            result *= (float) PlayerStats.damageMultiplier(data, magic);

            if (!magic && self.getRandom().nextDouble() * 100.0 < PlayerStats.critChance(data)) {
                result *= RealmforgeConfig.CRIT_MULTIPLIER;
                attacker.sendMessage(Text.literal("Critical hit!").formatted(Formatting.GOLD), true);
            }

            double lifesteal = PlayerStats.bonus(data, BonusType.LIFESTEAL);
            if (lifesteal > 0) {
                attacker.heal((float) (result * lifesteal / 100.0));
            }
        }

        // Victim mitigation (skip void / /kill style damage)
        if (self instanceof ServerPlayerEntity victim && !source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            result *= (float) (1.0 - PlayerStats.damageReduction(RPGPlayerData.get(victim)));
        }

        return result;
    }
}
