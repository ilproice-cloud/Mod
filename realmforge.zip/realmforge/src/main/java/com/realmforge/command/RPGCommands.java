package com.realmforge.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.realmforge.RealmforgeConfig;
import com.realmforge.network.RPGNetworkHandler;
import com.realmforge.player.PlayerStats;
import com.realmforge.player.RPGPlayerData;
import com.realmforge.player.StatType;
import com.realmforge.progression.LevelManager;
import com.realmforge.progression.RankManager;
import com.realmforge.registry.Race;
import com.realmforge.registry.RaceRegistry;
import com.realmforge.registry.Trait;
import com.realmforge.registry.TraitRegistry;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Arrays;

/** /rpg ... Works everywhere, including PojavLauncher where there is no M key. */
public final class RPGCommands {
    private RPGCommands() {}

    private static final SuggestionProvider<ServerCommandSource> STAT_SUGGESTIONS = (ctx, builder) ->
            CommandSource.suggestMatching(
                    Arrays.stream(StatType.values()).map(s -> s.name().toLowerCase()), builder);

    private static final SuggestionProvider<ServerCommandSource> RACE_SUGGESTIONS = (ctx, builder) ->
            CommandSource.suggestMatching(
                    RaceRegistry.all().stream().map(Race::id), builder);

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            LiteralArgumentBuilder<ServerCommandSource> admin = CommandManager.literal("admin")
                    .requires(src -> src.hasPermissionLevel(2))
                    .then(CommandManager.literal("addxp")
                            .then(CommandManager.argument("amount", IntegerArgumentType.integer(1))
                                    .executes(ctx -> {
                                        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                        LevelManager.addXp(p, IntegerArgumentType.getInteger(ctx, "amount"));
                                        return 1;
                                    })))
                    .then(CommandManager.literal("reroll")
                            .executes(ctx -> {
                                LevelManager.rerollTraits(ctx.getSource().getPlayerOrThrow());
                                return 1;
                            }))
                    .then(CommandManager.literal("reset")
                            .executes(ctx -> {
                                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                new RPGPlayerData().save(p);
                                PlayerStats.applyAttributes(p);
                                RPGNetworkHandler.sync(p);
                                ctx.getSource().sendFeedback(() -> Text.literal("RPG data reset."), false);
                                return 1;
                            }));

            dispatcher.register(CommandManager.literal("rpg")
                    .executes(ctx -> showStats(ctx.getSource()))
                    .then(CommandManager.literal("stats").executes(ctx -> showStats(ctx.getSource())))
                    .then(CommandManager.literal("spend")
                            .then(CommandManager.argument("stat", StringArgumentType.word())
                                    .suggests(STAT_SUGGESTIONS)
                                    .executes(ctx -> spend(ctx, 1))
                                    .then(CommandManager.argument("amount", IntegerArgumentType.integer(1, 1000))
                                            .executes(ctx -> spend(ctx, IntegerArgumentType.getInteger(ctx, "amount"))))))
                    .then(CommandManager.literal("race")
                            .then(CommandManager.argument("race", StringArgumentType.word())
                                    .suggests(RACE_SUGGESTIONS)
                                    .executes(RPGCommands::chooseRace)))
                    .then(admin));
        });
    }

    private static int spend(CommandContext<ServerCommandSource> ctx, int amount) throws CommandSyntaxException {
        ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
        StatType stat = StatType.fromName(StringArgumentType.getString(ctx, "stat"));
        if (stat == null) {
            ctx.getSource().sendError(Text.literal("Unknown stat. Try: vitality, strength, agility, intelligence, energy, defense, luck."));
            return 0;
        }
        if (!LevelManager.spend(player, stat, amount)) {
            ctx.getSource().sendError(Text.literal("Not enough stat points."));
            return 0;
        }
        ctx.getSource().sendFeedback(() -> Text.literal("+" + amount + " " + stat.displayName).formatted(stat.color), false);
        return 1;
    }

    private static int chooseRace(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
        RPGPlayerData d = RPGPlayerData.get(player);
        Race race = RaceRegistry.get(StringArgumentType.getString(ctx, "race").toLowerCase());
        if (race == null) {
            ctx.getSource().sendError(Text.literal("Unknown race."));
            return 0;
        }
        if (!d.race.isEmpty()) {
            ctx.getSource().sendError(Text.literal("You already chose a race."));
            return 0;
        }
        d.race = race.id();
        d.save(player);
        PlayerStats.applyAttributes(player);
        RPGNetworkHandler.sync(player);
        ctx.getSource().sendFeedback(() -> Text.literal("You are now a ").formatted(Formatting.GRAY)
                .append(Text.literal(race.name()).formatted(race.color()))
                .append(Text.literal(" (" + race.describeBonuses() + ")").formatted(Formatting.GRAY)), false);
        return 1;
    }

    private static int showStats(ServerCommandSource source) throws CommandSyntaxException {
        ServerPlayerEntity player = source.getPlayerOrThrow();
        RPGPlayerData d = RPGPlayerData.get(player);
        RankManager.Rank rank = RankManager.forLevel(d.level);
        Race race = RaceRegistry.get(d.race);

        source.sendFeedback(() -> Text.literal("== Realmforge ==").formatted(Formatting.GOLD, Formatting.BOLD), false);
        source.sendFeedback(() -> Text.literal("Level " + d.level + " | ").formatted(Formatting.WHITE)
                .append(Text.literal(rank.displayName).formatted(rank.color))
                .append(Text.literal(" | XP " + d.xp + "/" + LevelManager.xpNeeded(d.level)).formatted(Formatting.GREEN)), false);
        source.sendFeedback(() -> Text.literal("Energy " + d.energy + "/" + PlayerStats.maxEnergy(d)
                + " | Points: " + d.points).formatted(Formatting.YELLOW), false);
        source.sendFeedback(() -> Text.literal("Race: ").formatted(Formatting.GRAY)
                .append(race == null
                        ? Text.literal("none (/rpg race <name>)").formatted(Formatting.DARK_GRAY)
                        : Text.literal(race.name()).formatted(race.color())), false);
        for (StatType t : StatType.values()) {
            source.sendFeedback(() -> Text.literal(t.displayName + ": " + d.getStat(t)).formatted(t.color), false);
        }
        for (String id : d.traits) {
            Trait trait = TraitRegistry.get(id);
            if (trait != null) {
                source.sendFeedback(() -> Text.literal("[" + trait.rarity().displayName + "] " + trait.name()
                        + " (" + trait.describeBonuses() + ")").formatted(trait.rarity().color), false);
            }
        }
        return 1;
    }
}
