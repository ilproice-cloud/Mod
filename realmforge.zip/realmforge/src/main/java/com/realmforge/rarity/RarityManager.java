package com.realmforge.rarity;

import com.realmforge.registry.Trait;
import com.realmforge.registry.TraitRegistry;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public final class RarityManager {
    private RarityManager() {}

    /** Weighted random rarity. */
    public static Rarity roll() {
        double total = 0;
        for (Rarity r : Rarity.values()) total += r.weight;
        double pick = ThreadLocalRandom.current().nextDouble() * total;
        for (Rarity r : Rarity.values()) {
            pick -= r.weight;
            if (pick < 0) return r;
        }
        return Rarity.COMMON;
    }

    /** Rolls a rarity, then a trait of that rarity the player doesn't own. Falls back to lower rarities. */
    public static Trait rollTrait(Set<String> owned) {
        Rarity rolled = roll();
        for (int i = rolled.ordinal(); i >= 0; i--) {
            List<Trait> candidates = new ArrayList<>();
            for (Trait t : TraitRegistry.byRarity(Rarity.values()[i])) {
                if (!owned.contains(t.id())) candidates.add(t);
            }
            if (!candidates.isEmpty()) {
                return candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()));
            }
        }
        return null;
    }
}
