package com.realmforge.screen;

import com.realmforge.client.ClientRPGData;
import com.realmforge.network.SpendPointPayload;
import com.realmforge.player.StatType;
import com.realmforge.progression.RankManager;
import com.realmforge.registry.Perk;
import com.realmforge.registry.PerkRegistry;
import com.realmforge.registry.Race;
import com.realmforge.registry.RaceRegistry;
import com.realmforge.registry.Trait;
import com.realmforge.registry.TraitRegistry;
import com.realmforge.RealmforgeConfig;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Press M (or use the RPG button / /rpgmenu) to open. Tab 0 = Stats, tab 1 = Traits & Perks. */
public class RPGScreen extends Screen {
    private static final int PANEL_W = 240;
    private static final int PANEL_H = 290;
    private static final int ROW_H = 21;
    private static final int BTN = 20;
    private static final int PAD = 10;

    private final List<ButtonWidget> statButtons = new ArrayList<>();
    private int left, top;
    private int tab = 0;

    public RPGScreen() {
        super(Text.literal("Realmforge"));
    }

    @Override
    protected void init() {
        statButtons.clear();
        left = (width - PANEL_W) / 2;
        top = Math.max(2, (height - PANEL_H) / 2);

        StatType[] types = StatType.values();
        for (int i = 0; i < types.length; i++) {
            final int index = i;
            int y = top + 94 + i * ROW_H;
            ButtonWidget plus = ButtonWidget.builder(Text.literal("+"), b -> spend(index))
                    .dimensions(left + PANEL_W - BTN - PAD, y, BTN, BTN)
                    .build();
            statButtons.add(plus);
            addDrawableChild(plus);
        }

        int tabY = top + PANEL_H - 26;
        addDrawableChild(ButtonWidget.builder(Text.literal("Stats"), b -> setTab(0))
                .dimensions(left + PAD, tabY, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Traits"), b -> setTab(1))
                .dimensions(left + PAD + 75, tabY, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(left + PAD + 150, tabY, 70, 20).build());

        setTab(tab);
    }

    private void setTab(int newTab) {
        tab = newTab;
        for (ButtonWidget b : statButtons) {
            b.visible = tab == 0;
            b.active = tab == 0;
        }
    }

    private void spend(int statIndex) {
        if (ClientRPGData.points <= 0) return;
        // The server validates; it re-syncs if it disagrees.
        ClientPlayNetworking.send(new SpendPointPayload(statIndex));
        ClientRPGData.points--;
        ClientRPGData.stats[statIndex]++;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);

        ctx.fill(left, top, left + PANEL_W, top + PANEL_H, 0xE0101018);
        ctx.drawBorder(left, top, PANEL_W, PANEL_H, 0xFFB8860B);

        ctx.drawCenteredTextWithShadow(textRenderer,
                title.copy().formatted(Formatting.GOLD, Formatting.BOLD), width / 2, top + 8, 0xFFFFFF);

        RankManager.Rank rank = RankManager.forLevel(ClientRPGData.level);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Level " + ClientRPGData.level + "  |  ").formatted(Formatting.WHITE)
                        .append(Text.literal(rank.displayName).formatted(rank.color)),
                width / 2, top + 22, 0xFFFFFF);

        float hp = 0, maxHp = 20;
        if (client != null && client.player != null) {
            hp = client.player.getHealth();
            maxHp = client.player.getMaxHealth();
        }
        drawBar(ctx, top + 36, hp / Math.max(1f, maxHp), 0xFFCC2222, "HP " + (int) hp + " / " + (int) maxHp);
        drawBar(ctx, top + 50, (float) ClientRPGData.energy / Math.max(1, ClientRPGData.maxEnergy),
                0xFF2288DD, "Energy " + ClientRPGData.energy + " / " + ClientRPGData.maxEnergy);
        String xpLabel = ClientRPGData.level >= RealmforgeConfig.MAX_LEVEL
                ? "XP MAX" : "XP " + ClientRPGData.xp + " / " + ClientRPGData.xpNeeded;
        drawBar(ctx, top + 64, (float) ClientRPGData.xp / Math.max(1, ClientRPGData.xpNeeded), 0xFF44BB44, xpLabel);

        if (tab == 0) {
            renderStats(ctx);
        } else {
            renderTraits(ctx);
        }

        super.render(ctx, mouseX, mouseY, delta); // buttons
    }

    private void renderStats(DrawContext ctx) {
        ctx.drawTextWithShadow(textRenderer,
                Text.literal("Stat Points: " + ClientRPGData.points).formatted(Formatting.YELLOW),
                left + PAD, top + 82, 0xFFFFFF);

        StatType[] types = StatType.values();
        for (int i = 0; i < types.length; i++) {
            StatType t = types[i];
            int y = top + 94 + i * ROW_H;
            ctx.drawTextWithShadow(textRenderer,
                    Text.literal(t.displayName + ": " + ClientRPGData.stats[i]).formatted(t.color),
                    left + PAD, y + 1, 0xFFFFFF);
            ctx.drawTextWithShadow(textRenderer,
                    Text.literal(t.description).formatted(Formatting.GRAY),
                    left + PAD, y + 11, 0xFFFFFF);
        }
    }

    private void renderTraits(DrawContext ctx) {
        int y = top + 82;
        int maxTextW = PANEL_W - PAD * 2;

        Race race = RaceRegistry.get(ClientRPGData.race);
        Text raceLine = Text.literal("Race: ").formatted(Formatting.GRAY)
                .append(race == null
                        ? Text.literal("none (/rpg race <name>)").formatted(Formatting.DARK_GRAY)
                        : Text.literal(race.name()).formatted(race.color()));
        ctx.drawTextWithShadow(textRenderer, raceLine, left + PAD, y, 0xFFFFFF);
        y += 14;

        ctx.drawTextWithShadow(textRenderer,
                Text.literal("Traits (" + ClientRPGData.traits.size() + "/" + RealmforgeConfig.MAX_TRAITS + ")")
                        .formatted(Formatting.GOLD), left + PAD, y, 0xFFFFFF);
        y += 12;

        for (int i = 0; i < RealmforgeConfig.MAX_TRAITS; i++) {
            Trait trait = i < ClientRPGData.traits.size() ? TraitRegistry.get(ClientRPGData.traits.get(i)) : null;
            if (trait == null) {
                ctx.drawTextWithShadow(textRenderer,
                        Text.literal("Empty slot (roll every " + RealmforgeConfig.TRAIT_INTERVAL + " levels)")
                                .formatted(Formatting.DARK_GRAY), left + PAD, y + 4, 0xFFFFFF);
            } else {
                ctx.drawTextWithShadow(textRenderer,
                        Text.literal("[" + trait.rarity().displayName + "] " + trait.name())
                                .formatted(trait.rarity().color), left + PAD, y, 0xFFFFFF);
                ctx.drawTextWithShadow(textRenderer,
                        Text.literal(textRenderer.trimToWidth(trait.describeBonuses(), maxTextW))
                                .formatted(Formatting.GRAY), left + PAD, y + 10, 0xFFFFFF);
            }
            y += 21;
        }

        y += 4;
        ctx.drawTextWithShadow(textRenderer, Text.literal("Perks").formatted(Formatting.GOLD), left + PAD, y, 0xFFFFFF);
        y += 12;
        for (Perk perk : PerkRegistry.all()) {
            boolean unlocked = ClientRPGData.level >= perk.level();
            Text line = unlocked
                    ? Text.literal(perk.name()).formatted(perk.rarity().color)
                    : Text.literal(perk.name() + "  (Lv " + perk.level() + ")").formatted(Formatting.DARK_GRAY);
            ctx.drawTextWithShadow(textRenderer, line, left + PAD, y, 0xFFFFFF);
            y += 9;
        }
    }

    private void drawBar(DrawContext ctx, int y, float pct, int color, String label) {
        int x = left + PAD;
        int w = PANEL_W - PAD * 2;
        pct = Math.max(0f, Math.min(1f, pct));
        ctx.fill(x, y, x + w, y + 11, 0xFF222222);
        ctx.fill(x, y, x + (int) (w * pct), y + 11, color);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(label), x + w / 2, y + 2, 0xFFFFFF);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
