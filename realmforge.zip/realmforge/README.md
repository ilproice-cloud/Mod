# Realmforge

**Ascend. Forge. Conquer.**
An RPG progression mod for Minecraft 1.21.1 (Fabric): stats, ranks, races, and rarity-colored traits and perks.

## Build
Requires **Java 21**.

```
./gradlew build          # jar ends up in build/libs/
./gradlew runClient      # test in a dev client
./gradlew runServer      # test a dedicated server
```
Open the folder in IntelliJ IDEA (or VS Code) and import it as a Gradle project.
If a version in `gradle.properties` fails to resolve, pick the current 1.21.1 values from https://fabricmc.net/develop.

## Features
- **7 stats**: Vitality, Strength, Agility, Intelligence, Energy, Defense, Luck (values in `RealmforgeConfig.java`)
- **Levels 1-100** with 3 stat points per level, and **9 ranks** (Novice to Ascended)
- **Races** (Human, Elf, Dwarf, Orc): pick once with `/rpg race <name>`
- **Traits**: rolled every 5 levels, max 3 slots, 6 rarities with colors:
  Common (white), Uncommon (green), Rare (blue), Epic (purple), Legendary (gold), Mythic (red)
- **Perks**: passive bonuses that unlock at set levels
- **XP sources**: killing hostile mobs, mining ores
- Data is saved per player (Fabric Data Attachment API), kept on death, synced to the client

## Controls
| Action | How |
|---|---|
| Open the RPG screen | **M**, the **RPG** button on the inventory / pause screen, or `/rpgmenu` |
| Spend points | **+** buttons, or `/rpg spend <stat> [amount]` |
| Show stats as text | `/rpg` |
| Choose race | `/rpg race <human\|elf\|dwarf\|orc>` |
| Admin (OP 2) | `/rpg admin addxp <n>`, `/rpg admin reroll`, `/rpg admin reset` |

The RPG button, `/rpg` and `/rpgmenu` exist so PojavLauncher/mobile players don't need a keyboard.

## Project layout
```
com.realmforge
  RealmforgeMod / RealmforgeConfig
  player/       RPGPlayerData, PlayerStats, StatType, Bonus*
  rarity/       Rarity, RarityManager
  registry/     TraitRegistry, PerkRegistry, RaceRegistry
  progression/  LevelManager, RankManager
  network/      RPGNetworkHandler, SyncPayload, SpendPointPayload
  event/        RPGEvents (join, respawn, regen, XP)
  command/      RPGCommands
  mixin/        LivingEntityMixin (damage, crit, dodge, defense, lifesteal)
  client/       RealmforgeClient, ClientRPGData (keybind, HUD, sync)
  screen/       RPGScreen
```

## Test checklist
1. Singleplayer: kill a zombie, mine coal, level up, spend points
2. Dedicated server + 2 clients: stats sync, can't spend more points than you have
3. Die and respawn: stats and traits are kept, max HP is re-applied
4. Log out and in: everything persists
5. PojavLauncher (Java 21 runtime): open the screen with the RPG button, tap the + buttons

## Ideas for later
Energy-cost skills, dungeons/realms, forged gear with rarity, party/guild features, a trait reroll item.
